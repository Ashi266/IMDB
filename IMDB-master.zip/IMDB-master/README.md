# IMDB-clone 


visit this side  https://prakashuniyal01.github.io/IMDB/
